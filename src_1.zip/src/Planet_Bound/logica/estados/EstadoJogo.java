package Planet_Bound.logica.estados;

public enum EstadoJogo {
    GameOver,
    NovoShip,
    ConvertResources,
    OnSpaceStation,
    NoEspaco,
    NoTerreno
}
