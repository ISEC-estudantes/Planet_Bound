package Planet_Bound.logica.dados.aux;

public enum Direcoes {
    cima,baixo,esquerda,direita
}
