package Planet_Bound.logica.dados.resourcesandplanets;

public enum PlanetType {
    Blue,
    Black,
    Red,
    Green
}
