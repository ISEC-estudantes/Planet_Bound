var searchData=
[
  ['direcoes_358',['Direcoes',['../enumPlanet__Bound_1_1logica_1_1dados_1_1aux_1_1Direcoes.html',1,'Planet_Bound::logica::dados::aux']]],
  ['drone_359',['Drone',['../classPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1Terreno_1_1Drone.html',1,'Planet_Bound::logica::dados::resourcesandplanets::Terreno']]]
];
