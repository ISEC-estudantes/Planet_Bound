var searchData=
[
  ['secção_20das_20opções_765',['Secção das opções',['../group__secops.html',1,'']]]
];
