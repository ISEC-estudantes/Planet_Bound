var searchData=
[
  ['noespaco_384',['NoEspaco',['../classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1NoEspaco.html',1,'Planet_Bound::logica::estados::noespaco']]],
  ['noterreno_385',['NoTerreno',['../classPlanet__Bound_1_1logica_1_1estados_1_1noterreno_1_1NoTerreno.html',1,'Planet_Bound::logica::estados::noterreno']]],
  ['novoship_386',['NovoShip',['../classPlanet__Bound_1_1logica_1_1estados_1_1birthanddeath_1_1NovoShip.html',1,'Planet_Bound::logica::estados::birthanddeath']]]
];
