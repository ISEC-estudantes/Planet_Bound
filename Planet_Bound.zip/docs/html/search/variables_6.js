var searchData=
[
  ['gameover_679',['GameOver',['../enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#a6a076df93c3da837f850d9cd28371f27',1,'Planet_Bound.logica.dados.events.EventType.GameOver()'],['../enumPlanet__Bound_1_1logica_1_1estados_1_1EstadoJogo.html#acb5ecf1a3c7f64cd90dde072dbe7b169',1,'Planet_Bound.logica.estados.EstadoJogo.GameOver()']]],
  ['ganhados_680',['ganhados',['../group__group__shipDadosEvents.html#ga7e834bd9b9608f9e7b368d5a7f908537',1,'Planet_Bound::logica::dados::ship::ShipDados']]],
  ['glog_681',['gLog',['../classPlanet__Bound_1_1ui_1_1gui_1_1Root.html#ae8cfe51abfd1b670d9c19a38cc41617f',1,'Planet_Bound::ui::gui::Root']]],
  ['grecursos_682',['gRecursos',['../classPlanet__Bound_1_1ui_1_1gui_1_1Root.html#a8ba72455314e9968ca1e266653de24c8',1,'Planet_Bound::ui::gui::Root']]],
  ['green_683',['Green',['../enumPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1PlanetType.html#a91ce9391563df32310684efc6b7db387',1,'Planet_Bound.logica.dados.resourcesandplanets.PlanetType.Green()'],['../enumPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1Resource.html#a28fa6800951c96f4bd9890bd12676bf5',1,'Planet_Bound.logica.dados.resourcesandplanets.Resource.Green()']]],
  ['gtop_684',['gTop',['../classPlanet__Bound_1_1ui_1_1gui_1_1Root.html#a2ca7fc930d530f466afbb40e756b776e',1,'Planet_Bound::ui::gui::Root']]]
];
