var searchData=
[
  ['file_676',['file',['../classPlanet__Bound_1_1ui_1_1gui_1_1menu_1_1GMenu.html#aa308a8ebb3cfa09bfca8b3043d63c38d',1,'Planet_Bound::ui::gui::menu::GMenu']]],
  ['fuel_677',['Fuel',['../enumPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1Resource.html#aefa8f8c08507e808598693287ca60232',1,'Planet_Bound::logica::dados::resourcesandplanets::Resource']]],
  ['fuel_5fmax_678',['fuel_max',['../classPlanet__Bound_1_1logica_1_1dados_1_1ship_1_1ShipDados.html#a5bbe10f8ec17518fb821ca9059ad41e7',1,'Planet_Bound::logica::dados::ship::ShipDados']]]
];
