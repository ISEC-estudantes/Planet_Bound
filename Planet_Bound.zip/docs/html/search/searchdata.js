var indexSectionsWithContent =
{
  0: "abcdefghilmnopqrstuvw",
  1: "acdeghimnoprst",
  2: "p",
  3: "cdeghimnoprst",
  4: "abcdefghilmnoprstuv",
  5: "abcdefghilmnopqrstuvw",
  6: "dgrs",
  7: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "groups",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Namespaces",
  3: "Ficheiros",
  4: "Funções",
  5: "Variáveis",
  6: "Grupos",
  7: "Páginas"
};

