var namespacePlanet__Bound_1_1logica_1_1dados_1_1ship =
[
    [ "ShipDados", "classPlanet__Bound_1_1logica_1_1dados_1_1ship_1_1ShipDados.html", "classPlanet__Bound_1_1logica_1_1dados_1_1ship_1_1ShipDados" ],
    [ "ShipType", "enumPlanet__Bound_1_1logica_1_1dados_1_1ship_1_1ShipType.html", "enumPlanet__Bound_1_1logica_1_1dados_1_1ship_1_1ShipType" ]
];