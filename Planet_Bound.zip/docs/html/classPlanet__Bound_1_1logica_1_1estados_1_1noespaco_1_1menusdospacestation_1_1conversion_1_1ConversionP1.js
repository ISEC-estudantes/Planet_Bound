var classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1conversion_1_1ConversionP1 =
[
    [ "ConversionP1", "classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1conversion_1_1ConversionP1.html#a409f5902eb2247e620fa090ee05ce320", null ],
    [ "getEstado", "classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1conversion_1_1ConversionP1.html#ace7555ccdca01de304ec32f06de5a7c1", null ],
    [ "setOpcao", "classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1conversion_1_1ConversionP1.html#a04fde2219e0c0314e96c834ebab8c083", null ],
    [ "listaresources", "classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1conversion_1_1ConversionP1.html#a902a5f6cadcd03e6bb8a9e8c9bb7902b", null ],
    [ "onSpaceStation", "classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1conversion_1_1ConversionP1.html#a0ab460a4efb477ed28082c8218ae4e54", null ]
];