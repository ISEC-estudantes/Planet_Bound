var dir_92bbc3c9ac2ca8428a5a661577b2fbb8 =
[
    [ "conversion", "dir_6133e50da9a5e1be24937e7d54a1b4ed.html", "dir_6133e50da9a5e1be24937e7d54a1b4ed" ],
    [ "OnSpaceStation.java", "OnSpaceStation_8java.html", [
      [ "OnSpaceStation", "classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1OnSpaceStation.html", "classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1OnSpaceStation" ]
    ] ]
];