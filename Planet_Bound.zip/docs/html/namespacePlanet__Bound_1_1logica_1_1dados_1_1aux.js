var namespacePlanet__Bound_1_1logica_1_1dados_1_1aux =
[
    [ "Direcoes", "enumPlanet__Bound_1_1logica_1_1dados_1_1aux_1_1Direcoes.html", "enumPlanet__Bound_1_1logica_1_1dados_1_1aux_1_1Direcoes" ],
    [ "Officer", "enumPlanet__Bound_1_1logica_1_1dados_1_1aux_1_1Officer.html", "enumPlanet__Bound_1_1logica_1_1dados_1_1aux_1_1Officer" ],
    [ "Options", "classPlanet__Bound_1_1logica_1_1dados_1_1aux_1_1Options.html", "classPlanet__Bound_1_1logica_1_1dados_1_1aux_1_1Options" ]
];