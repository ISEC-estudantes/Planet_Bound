var namespacePlanet__Bound_1_1logica_1_1estados_1_1birthanddeath =
[
    [ "GameOver", "classPlanet__Bound_1_1logica_1_1estados_1_1birthanddeath_1_1GameOver.html", "classPlanet__Bound_1_1logica_1_1estados_1_1birthanddeath_1_1GameOver" ],
    [ "NovoShip", "classPlanet__Bound_1_1logica_1_1estados_1_1birthanddeath_1_1NovoShip.html", "classPlanet__Bound_1_1logica_1_1estados_1_1birthanddeath_1_1NovoShip" ]
];