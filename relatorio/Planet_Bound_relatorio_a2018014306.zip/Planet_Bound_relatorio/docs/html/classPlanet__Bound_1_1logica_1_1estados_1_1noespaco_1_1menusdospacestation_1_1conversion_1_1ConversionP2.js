var classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1conversion_1_1ConversionP2 =
[
    [ "ConversionP2", "classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1conversion_1_1ConversionP2.html#a52a1bf83f6a7d2abb9400c63836eeee9", null ],
    [ "converterXfromY", "classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1conversion_1_1ConversionP2.html#a31d1d447086e66bc663c898964b34d29", null ],
    [ "getEstado", "classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1conversion_1_1ConversionP2.html#ab1cbdfc7d4c6f43abe0e102a4b9e34ef", null ],
    [ "resourceExiste", "classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1conversion_1_1ConversionP2.html#a317e552fd9b1da0f471d9a1167e9440a", null ],
    [ "setOpcao", "classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1conversion_1_1ConversionP2.html#a036ff05041e80fc5a55e9e7a50134bae", null ],
    [ "listaresources", "classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1conversion_1_1ConversionP2.html#aa462d93f6a951ee7107fde8df38df467", null ],
    [ "localresource", "classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1conversion_1_1ConversionP2.html#a409a7cc9b9948be264ab9015b0b3b46e", null ],
    [ "onSpaceStation", "classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1conversion_1_1ConversionP2.html#a3eecca9f78d2d56f6f2d5d4edeaca1d8", null ]
];