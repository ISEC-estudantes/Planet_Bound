var classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha =
[
    [ "GEscolha", "classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha.html#a8ced89ca16d41672d1ecd7dbee8f0443", null ],
    [ "addTitle", "classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha.html#aa6e2839c07c244918fc377ef93f5450b", null ],
    [ "atualizaVista", "classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha.html#acc24c158f88d50209ffb31dc1797dc47", null ],
    [ "bSOButtons", "classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha.html#abc00157ab3be93497f52598cac8b9553", null ],
    [ "bSOSquares", "classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha.html#af22957ceb225ccde23579879c9bb7988", null ],
    [ "setUpButtons", "classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha.html#a8a4b6000415d2303bc48c02d44ea42c0", null ],
    [ "escolhas", "classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha.html#a485be1c4fd15aa7575ebcdc8dd41ec11", null ],
    [ "lastState", "classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha.html#a8014c53b4d4c7ef1f19fd786cbe2fdc7", null ],
    [ "modelo", "classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha.html#a9be82262fd0bb2fddb51c95b8dc7ca74", null ],
    [ "questao", "classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha.html#af49bf16cd18ec237090ec558c50e0b7d", null ],
    [ "questaoBox", "classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha.html#a14e9f3f8b4bc17143d62913a32b7623d", null ],
    [ "questaoSquare", "classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha.html#a36e99083907db29fac851948926693c8", null ]
];