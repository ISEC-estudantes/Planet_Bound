var dir_c42a8f681bf848f577f3a8b61855c640 =
[
    [ "aux", "dir_e911c2fc1ae67bfcd8296192a4b3e0e0.html", "dir_e911c2fc1ae67bfcd8296192a4b3e0e0" ],
    [ "events", "dir_c43803bca69d2ff2c34b673809a5f181.html", "dir_c43803bca69d2ff2c34b673809a5f181" ],
    [ "resourcesandplanets", "dir_8243ced59dabc61f2f3596f82c74eefd.html", "dir_8243ced59dabc61f2f3596f82c74eefd" ],
    [ "ship", "dir_05e26ef3ff8b07e5d72e7077af691239.html", "dir_05e26ef3ff8b07e5d72e7077af691239" ]
];