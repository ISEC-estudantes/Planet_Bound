var interfacePlanet__Bound_1_1logica_1_1estados_1_1IEstado =
[
    [ "aplicaEvento", "interfacePlanet__Bound_1_1logica_1_1estados_1_1IEstado.html#a5a1723e84127a8f0ffcf6dec02e2e080", null ],
    [ "convertResources", "interfacePlanet__Bound_1_1logica_1_1estados_1_1IEstado.html#aaf2e4feef2d105d86d1dc5540479c80c", null ],
    [ "getEstado", "interfacePlanet__Bound_1_1logica_1_1estados_1_1IEstado.html#aaf76db113bede1b1af79b34a7a5e1e48", null ],
    [ "landOnSpaceStation", "interfacePlanet__Bound_1_1logica_1_1estados_1_1IEstado.html#a31aa980018c4a44059c38f1f62ece5e3", null ],
    [ "landOnThePlanet", "interfacePlanet__Bound_1_1logica_1_1estados_1_1IEstado.html#ab19441b148e054c871bf9c60f47c0410", null ],
    [ "move", "interfacePlanet__Bound_1_1logica_1_1estados_1_1IEstado.html#a12eefa47ef9d468c3d66d4c24a5b202d", null ],
    [ "novoJogo", "interfacePlanet__Bound_1_1logica_1_1estados_1_1IEstado.html#a0ca19eab26fdf19a980fcfb12e193a44", null ],
    [ "proximoPlaneta", "interfacePlanet__Bound_1_1logica_1_1estados_1_1IEstado.html#abb9132c8d38c627c385d4ad2a4ec4d95", null ],
    [ "returnToShip", "interfacePlanet__Bound_1_1logica_1_1estados_1_1IEstado.html#aa87e107049580a7eb67c23931867bd7c", null ],
    [ "setOpcao", "interfacePlanet__Bound_1_1logica_1_1estados_1_1IEstado.html#a1aa405a2c1e1ef00ed092e1aadb92b49", null ]
];