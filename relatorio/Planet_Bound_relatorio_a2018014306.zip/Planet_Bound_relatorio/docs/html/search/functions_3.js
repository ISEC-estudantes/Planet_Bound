var searchData=
[
  ['deleteallresourcesoftypey_482',['deleteAllResourcesOfTypeY',['../group__secops.html#ga52e69ce2b39e92797cf94ef23385703a',1,'Planet_Bound::logica::dados::ship::ShipDados']]],
  ['deleteterreno_483',['deleteTerreno',['../classPlanet__Bound_1_1logica_1_1dados_1_1ship_1_1ShipDados.html#a83979dc19a3d426732fa59dc3f8994c7',1,'Planet_Bound::logica::dados::ship::ShipDados']]],
  ['deletexresourcesoftypey_484',['deleteXResourcesOfTypeY',['../group__secops.html#ga9f5da5b8215d78b40b15e6f424dd3e49',1,'Planet_Bound::logica::dados::ship::ShipDados']]],
  ['devoltaashipcomrecurso_485',['deVoltaAShipComRecurso',['../classPlanet__Bound_1_1logica_1_1dados_1_1ship_1_1ShipDados.html#adc94ea9ea1aeed3db6f119f40569036c',1,'Planet_Bound::logica::dados::ship::ShipDados']]],
  ['direcao_486',['direcao',['../classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GTerreno.html#a83b2997100ccca8aad3453712bfe2c42',1,'Planet_Bound::ui::gui::estados::GTerreno']]],
  ['drone_487',['Drone',['../classPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1Terreno_1_1Drone.html#a760d37338659d64710c46000724e1c5c',1,'Planet_Bound::logica::dados::resourcesandplanets::Terreno::Drone']]],
  ['dronehasresource_488',['droneHasResource',['../classPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1Terreno.html#a39a0d3118923007e285fa92928bfab39',1,'Planet_Bound.logica.dados.resourcesandplanets.Terreno.droneHasResource()'],['../group__group__getsfromShipDados.html#gabd13bcdd81b10a08878b7ace41bebcfe',1,'Planet_Bound.logica.Ship.droneHasResource()'],['../classPlanet__Bound_1_1logica_1_1Ship_1_1ITerreno.html#a6bc6637d32522c8e0027391f4ea5571d',1,'Planet_Bound.logica.Ship.ITerreno.droneHasResource()'],['../classPlanet__Bound_1_1logica_1_1ShipObservavel.html#a2413455fc2404f946ad6226785e48e1e',1,'Planet_Bound.logica.ShipObservavel.droneHasResource()']]]
];
