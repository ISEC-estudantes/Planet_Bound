var searchData=
[
  ['vezesquesepodevizitaroplaneta_758',['vezesQueSePodeVizitarOPlaneta',['../classPlanet__Bound_1_1logica_1_1dados_1_1ship_1_1ShipDados.html#a92394c9a936739f439836ec96f8e9d01',1,'Planet_Bound::logica::dados::ship::ShipDados']]]
];
