var searchData=
[
  ['warning_352',['Warning',['../enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#a4c542c76d036ddb32c16ca8b3ff52ca1',1,'Planet_Bound::logica::dados::events::EventType']]],
  ['weapon_5fmax_353',['weapon_max',['../classPlanet__Bound_1_1logica_1_1dados_1_1ship_1_1ShipDados.html#a57d1b43f625ee25a7810b1013efd6a0d',1,'Planet_Bound::logica::dados::ship::ShipDados']]],
  ['weapons_354',['Weapons',['../enumPlanet__Bound_1_1logica_1_1dados_1_1aux_1_1Officer.html#a9a2aca6953c7911406cf6c7d7fd0b95f',1,'Planet_Bound::logica::dados::aux::Officer']]],
  ['wormhole_355',['WormHole',['../enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#a2cc476362c99eac8e49e21d390c1a70d',1,'Planet_Bound::logica::dados::events::EventType']]]
];
