var searchData=
[
  ['verificaeretiranrecursosdotipoyparaobterx_349',['verificaeretiraNrecursosdotipoYparaobterX',['../classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1menusdospacestation_1_1OnSpaceStation.html#a46550913253beb7482f7e209f1f48aa4',1,'Planet_Bound.logica.estados.noespaco.menusdospacestation.OnSpaceStation.verificaeretiraNrecursosdotipoYparaobterX()'],['../group__secops.html#gaa28fac3e164e1371fd06221ea7b69b09',1,'Planet_Bound.logica.dados.ship.ShipDados.verificaeRetiraNrecursosdotipoYparaobterX()']]],
  ['versao_350',['versao',['../classPlanet__Bound_1_1Main.html#a764256da5ba27617dc9010ef78baf17e',1,'Planet_Bound::Main']]],
  ['vezesquesepodevizitaroplaneta_351',['vezesQueSePodeVizitarOPlaneta',['../classPlanet__Bound_1_1logica_1_1dados_1_1ship_1_1ShipDados.html#a92394c9a936739f439836ec96f8e9d01',1,'Planet_Bound::logica::dados::ship::ShipDados']]]
];
