var searchData=
[
  ['delegated_20gets_20do_20shipdados_763',['Delegated gets do shipDados',['../group__group__getsfromShipDados.html',1,'']]]
];
