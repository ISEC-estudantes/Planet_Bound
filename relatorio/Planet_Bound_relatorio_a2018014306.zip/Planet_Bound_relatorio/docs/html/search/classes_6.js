var searchData=
[
  ['iestado_380',['IEstado',['../interfacePlanet__Bound_1_1logica_1_1estados_1_1IEstado.html',1,'Planet_Bound::logica::estados']]],
  ['infoespaco_381',['InfoEspaco',['../classPlanet__Bound_1_1ui_1_1gui_1_1info_1_1extraInfo_1_1InfoEspaco.html',1,'Planet_Bound::ui::gui::info::extraInfo']]],
  ['infoplaneta_382',['InfoPlaneta',['../classPlanet__Bound_1_1ui_1_1gui_1_1info_1_1extraInfo_1_1InfoPlaneta.html',1,'Planet_Bound::ui::gui::info::extraInfo']]],
  ['iterreno_383',['ITerreno',['../classPlanet__Bound_1_1logica_1_1Ship_1_1ITerreno.html',1,'Planet_Bound::logica::Ship']]]
];
