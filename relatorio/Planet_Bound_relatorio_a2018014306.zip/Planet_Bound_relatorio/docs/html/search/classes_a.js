var searchData=
[
  ['planettype_391',['PlanetType',['../enumPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1PlanetType.html',1,'Planet_Bound::logica::dados::resourcesandplanets']]]
];
