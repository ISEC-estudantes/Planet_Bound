var group__group__getsfromShipDados =
[
    [ "ClearEvents", "group__group__getsfromShipDados.html#gafbb7f44d390d8c218d9344f26f861c7c", null ],
    [ "droneHasResource", "group__group__getsfromShipDados.html#gabd13bcdd81b10a08878b7ace41bebcfe", null ],
    [ "getCargoHold", "group__group__getsfromShipDados.html#gae7102fcb9ed20c0e76e7f86540a49ff5", null ],
    [ "getEstado", "group__group__getsfromShipDados.html#gac7c74551a67daa03a7423e72edfbf8c9", null ],
    [ "getEstadoClass", "group__group__getsfromShipDados.html#ga8f3277ecd8369e29c70cc063f22a93df", null ],
    [ "getMaxOfResourceY", "group__group__getsfromShipDados.html#gace939449dabf4a972b42f2f921ec865d", null ],
    [ "getNdeYRecursos", "group__group__getsfromShipDados.html#ga62b5ad4265a84b2e910c08eee1d0ba5a", null ],
    [ "getOfficers", "group__group__getsfromShipDados.html#ga1fa3be38a2969df272255f41806c8cd1", null ],
    [ "getOptions", "group__group__getsfromShipDados.html#gafb8894309f6218c1fa1a241c3e049fc9", null ],
    [ "getPlanetType", "group__group__getsfromShipDados.html#gab50a16f38b86cf96ce817ba4c16be366", null ],
    [ "getResourceTypes", "group__group__getsfromShipDados.html#ga235394aa5b297e1ded1bcb23a5aa250a", null ],
    [ "getShipType", "group__group__getsfromShipDados.html#ga1dd1b4fd9b565e6a610f178c754b0580", null ],
    [ "getUnreadEvents", "group__group__getsfromShipDados.html#ga7021fe94fb1b54706a3946834d969869", null ],
    [ "getVezesQueSePodeVizitarOPlaneta", "group__group__getsfromShipDados.html#ga6f2ef1d94fe62916a5dc51d600191628", null ],
    [ "hasDrone", "group__group__getsfromShipDados.html#gaa79473d61fcbae18d6c498780dfb2402", null ],
    [ "hasOfficer", "group__group__getsfromShipDados.html#ga8997cf7a73b73a85fbda1acba2655d90", null ],
    [ "hasSpaceStation", "group__group__getsfromShipDados.html#ga1477a4ceae3e5eb4fd6ce0c5ce323379", null ]
];