var namespacePlanet__Bound_1_1logica =
[
    [ "dados", "namespacePlanet__Bound_1_1logica_1_1dados.html", "namespacePlanet__Bound_1_1logica_1_1dados" ],
    [ "estados", "namespacePlanet__Bound_1_1logica_1_1estados.html", "namespacePlanet__Bound_1_1logica_1_1estados" ],
    [ "Ship", "classPlanet__Bound_1_1logica_1_1Ship.html", "classPlanet__Bound_1_1logica_1_1Ship" ],
    [ "ShipObservavel", "classPlanet__Bound_1_1logica_1_1ShipObservavel.html", "classPlanet__Bound_1_1logica_1_1ShipObservavel" ]
];