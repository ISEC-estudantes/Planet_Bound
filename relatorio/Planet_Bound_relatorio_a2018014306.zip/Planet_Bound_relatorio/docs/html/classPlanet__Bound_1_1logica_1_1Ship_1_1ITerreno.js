var classPlanet__Bound_1_1logica_1_1Ship_1_1ITerreno =
[
    [ "types", "enumPlanet__Bound_1_1logica_1_1Ship_1_1ITerreno_1_1types.html", "enumPlanet__Bound_1_1logica_1_1Ship_1_1ITerreno_1_1types" ],
    [ "ITerreno", "classPlanet__Bound_1_1logica_1_1Ship_1_1ITerreno.html#a0ea3e8706378b81cd99a3818a76b7162", null ],
    [ "droneHasResource", "classPlanet__Bound_1_1logica_1_1Ship_1_1ITerreno.html#a6bc6637d32522c8e0027391f4ea5571d", null ],
    [ "getAlienType", "classPlanet__Bound_1_1logica_1_1Ship_1_1ITerreno.html#a885b3963cc70146085e231ccedc7cb52", null ],
    [ "getCoordenadas", "classPlanet__Bound_1_1logica_1_1Ship_1_1ITerreno.html#ab2144976a34a3a9ba4faa79591516d97", null ],
    [ "getCoordenadas", "classPlanet__Bound_1_1logica_1_1Ship_1_1ITerreno.html#a7be155ddfb08e1e81093d70f9fd2b400", null ],
    [ "getCounter", "classPlanet__Bound_1_1logica_1_1Ship_1_1ITerreno.html#a3455b0957c89000087673d0923ac522b", null ],
    [ "getDroneHealth", "classPlanet__Bound_1_1logica_1_1Ship_1_1ITerreno.html#a6f01ee31662d71c5c89a717f234fdf64", null ],
    [ "getResourceType", "classPlanet__Bound_1_1logica_1_1Ship_1_1ITerreno.html#a0376df0253cf03cb9bfdeda8700386a5", null ],
    [ "getTerreno", "classPlanet__Bound_1_1logica_1_1Ship_1_1ITerreno.html#a7ca05a6986ebafcd5ca91a6f1ecef6c5", null ],
    [ "terreno", "classPlanet__Bound_1_1logica_1_1Ship_1_1ITerreno.html#a29be2866a52db17bba33daf4b2dd1513", null ]
];