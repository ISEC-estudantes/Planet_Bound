var enumPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1Resource =
[
    [ "Ammo", "enumPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1Resource.html#a084f6f5429a88ea3c49d7d1693702f4e", null ],
    [ "Artifact", "enumPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1Resource.html#acba10b0cca9cbf8a9a4458e530fabc5d", null ],
    [ "Black", "enumPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1Resource.html#ac0eb3ec8e288f3a818123d83fd866a66", null ],
    [ "Blue", "enumPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1Resource.html#a6f351b4d513dd4f090b495b2cd58d342", null ],
    [ "Fuel", "enumPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1Resource.html#aefa8f8c08507e808598693287ca60232", null ],
    [ "Green", "enumPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1Resource.html#a28fa6800951c96f4bd9890bd12676bf5", null ],
    [ "Red", "enumPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1Resource.html#aeb0d52500185d4cd1e9fdbec5024fad6", null ],
    [ "Shield", "enumPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1Resource.html#a20d3dce0fdec6d453477d5ab1bde5057", null ]
];