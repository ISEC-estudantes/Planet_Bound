var classPlanet__Bound_1_1logica_1_1estados_1_1birthanddeath_1_1GameOver =
[
    [ "GameOver", "classPlanet__Bound_1_1logica_1_1estados_1_1birthanddeath_1_1GameOver.html#a7a37acf2ed7108b7222b74308b47a226", null ],
    [ "getEstado", "classPlanet__Bound_1_1logica_1_1estados_1_1birthanddeath_1_1GameOver.html#ab94c635892a8c43c6384286a5646365e", null ],
    [ "novoJogo", "classPlanet__Bound_1_1logica_1_1estados_1_1birthanddeath_1_1GameOver.html#a14173c013132ccc5cd3905b32576be1f", null ],
    [ "toString", "classPlanet__Bound_1_1logica_1_1estados_1_1birthanddeath_1_1GameOver.html#adc507bac9f3881d2c9f7e71f2fbd3633", null ],
    [ "mensagem", "classPlanet__Bound_1_1logica_1_1estados_1_1birthanddeath_1_1GameOver.html#a7db61c04146a0cbe8d5eb4bf3f9504a6", null ]
];