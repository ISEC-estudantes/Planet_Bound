var enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType =
[
    [ "AlienKilled", "enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#ada99808437ac388e9bcdb99a6bcacfa8", null ],
    [ "ChoosenItem", "enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#a07ee2e848171b292ab5507d28a49cc60", null ],
    [ "ConversorDeItens", "enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#abce09730c89694565509055da995e99e", null ],
    [ "Debug", "enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#ae1f04d1c388677fac97386f49d61f989", null ],
    [ "DroneDeath", "enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#a23ca0489415ee64ce0639bfd65c34dde", null ],
    [ "DroneMovement", "enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#ad88ea854f61bd0cd62313d1b3e8cf562", null ],
    [ "GameOver", "enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#a6a076df93c3da837f850d9cd28371f27", null ],
    [ "Info", "enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#a5bd147b9253db47b2d59d34174d8de39", null ],
    [ "MoreResources", "enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#a1445d65bc3dba91e491f9eeaf2c4d38b", null ],
    [ "NovoPlaneta", "enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#abb02e08b690e4b4d0dc8c4fb2c592861", null ],
    [ "NovoShip", "enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#acc3c186f53f97f0def8d15e1dd0fe7e9", null ],
    [ "OnSpaceStation", "enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#a09fc696e75033e52dcb1822c98f7f291", null ],
    [ "RandomEvent", "enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#a086f9ab15a6b6049b8b478a1ab8be20d", null ],
    [ "Warning", "enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#a4c542c76d036ddb32c16ca8b3ff52ca1", null ],
    [ "WormHole", "enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#a2cc476362c99eac8e49e21d390c1a70d", null ]
];