var classPlanet__Bound_1_1logica_1_1estados_1_1birthanddeath_1_1NovoShip =
[
    [ "NovoShip", "classPlanet__Bound_1_1logica_1_1estados_1_1birthanddeath_1_1NovoShip.html#a28bba8f52214b194e52c67ba8b7b0958", null ],
    [ "getEstado", "classPlanet__Bound_1_1logica_1_1estados_1_1birthanddeath_1_1NovoShip.html#a693671103b7dd137af61f961a3b95852", null ],
    [ "setOpcao", "classPlanet__Bound_1_1logica_1_1estados_1_1birthanddeath_1_1NovoShip.html#afa4464ca3162294ee7d78dffb621f74b", null ]
];