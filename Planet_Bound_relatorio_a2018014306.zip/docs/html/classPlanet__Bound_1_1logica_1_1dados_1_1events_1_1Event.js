var classPlanet__Bound_1_1logica_1_1dados_1_1events_1_1Event =
[
    [ "Event", "classPlanet__Bound_1_1logica_1_1dados_1_1events_1_1Event.html#a964e4556b5b3e77256ea84235641167f", null ],
    [ "getEventType", "classPlanet__Bound_1_1logica_1_1dados_1_1events_1_1Event.html#ad934d2189c7e4123a982e943c0b5839f", null ],
    [ "getMsg", "classPlanet__Bound_1_1logica_1_1dados_1_1events_1_1Event.html#ade754083149e40affce16584b2d87101", null ],
    [ "getTimeWithoutMilisecs", "classPlanet__Bound_1_1logica_1_1dados_1_1events_1_1Event.html#a2dda61717ddf1cf368b8f6a0d4ecddc1", null ],
    [ "getUnixTimewithMilisecs", "classPlanet__Bound_1_1logica_1_1dados_1_1events_1_1Event.html#afb0be959e2dee08a518b8701d39fc3e6", null ],
    [ "toString", "classPlanet__Bound_1_1logica_1_1dados_1_1events_1_1Event.html#a4266150e824f3813aba0a44e57cc3a40", null ],
    [ "eventType", "classPlanet__Bound_1_1logica_1_1dados_1_1events_1_1Event.html#a1cba083d101fa62ab05f652dd8e3538b", null ],
    [ "msg", "classPlanet__Bound_1_1logica_1_1dados_1_1events_1_1Event.html#ae5cc832972c33bc8b31bd3ac9869954a", null ],
    [ "unixTimewithMilisecs", "classPlanet__Bound_1_1logica_1_1dados_1_1events_1_1Event.html#a8ffab5b03575e25737673563431c8af1", null ]
];