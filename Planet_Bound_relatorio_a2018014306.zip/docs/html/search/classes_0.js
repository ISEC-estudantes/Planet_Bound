var searchData=
[
  ['alien_355',['Alien',['../classPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1Terreno_1_1Alien.html',1,'Planet_Bound::logica::dados::resourcesandplanets::Terreno']]]
];
