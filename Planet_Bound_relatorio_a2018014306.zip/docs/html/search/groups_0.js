var searchData=
[
  ['delegated_20gets_20do_20shipdados_762',['Delegated gets do shipDados',['../group__group__getsfromShipDados.html',1,'']]]
];
