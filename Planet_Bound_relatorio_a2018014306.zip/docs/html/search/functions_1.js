var searchData=
[
  ['bsobuttons_469',['bSOButtons',['../classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha.html#abc00157ab3be93497f52598cac8b9553',1,'Planet_Bound::ui::gui::estados::GEscolha']]],
  ['bsosquares_470',['bSOSquares',['../classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha.html#af22957ceb225ccde23579879c9bb7988',1,'Planet_Bound::ui::gui::estados::GEscolha']]]
];
