var searchData=
[
  ['questao_271',['questao',['../classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha.html#af49bf16cd18ec237090ec558c50e0b7d',1,'Planet_Bound.ui.gui.estados.GEscolha.questao()'],['../classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GGameOver.html#a1cc9cb768eb8b99b42a83c2de9d47ddf',1,'Planet_Bound.ui.gui.estados.GGameOver.questao()']]],
  ['questaobox_272',['questaoBox',['../classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha.html#a14e9f3f8b4bc17143d62913a32b7623d',1,'Planet_Bound::ui::gui::estados::GEscolha']]],
  ['questaosquare_273',['questaoSquare',['../classPlanet__Bound_1_1ui_1_1gui_1_1estados_1_1GEscolha.html#a36e99083907db29fac851948926693c8',1,'Planet_Bound::ui::gui::estados::GEscolha']]]
];
