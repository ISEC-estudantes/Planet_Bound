var searchData=
[
  ['fillvector_490',['fillVector',['../classPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1ResourceTypes.html#a6b6e49b4291d30ad5a83dc0043ccd438',1,'Planet_Bound.logica.dados.resourcesandplanets.ResourceTypes.fillVector(Vector&lt; Resource &gt; vector, Resource... resources)'],['../classPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1ResourceTypes.html#a8ceb2f5cdef37ed02cc5434faafcdc3e',1,'Planet_Bound.logica.dados.resourcesandplanets.ResourceTypes.fillVector(Vector&lt; Resource &gt; vector, Resource resource, int ntimes)']]]
];
