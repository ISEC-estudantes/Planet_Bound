var searchData=
[
  ['nearby_581',['nearBy',['../classPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1Terreno.html#aff43d1bc500032bee86b0c644673764a',1,'Planet_Bound::logica::dados::resourcesandplanets::Terreno']]],
  ['newrandomlocation_582',['newRandomLocation',['../classPlanet__Bound_1_1logica_1_1dados_1_1resourcesandplanets_1_1Terreno_1_1Entidade.html#a8b5283c921a73a7dbb641d15e71a4c47',1,'Planet_Bound::logica::dados::resourcesandplanets::Terreno::Entidade']]],
  ['newterreno_583',['newTerreno',['../group__group__shipDadosEvents.html#gae81bc19bceaa3d13e64ee090675593fc',1,'Planet_Bound::logica::dados::ship::ShipDados']]],
  ['noespaco_584',['NoEspaco',['../classPlanet__Bound_1_1logica_1_1estados_1_1noespaco_1_1NoEspaco.html#add2cafadb4c4f367a4497a11e2f5fbfa',1,'Planet_Bound::logica::estados::noespaco::NoEspaco']]],
  ['noterreno_585',['NoTerreno',['../classPlanet__Bound_1_1logica_1_1estados_1_1noterreno_1_1NoTerreno.html#a99b6f0e03a88a964e4ffc2860d02ae54',1,'Planet_Bound::logica::estados::noterreno::NoTerreno']]],
  ['novojogo_586',['novoJogo',['../classPlanet__Bound_1_1logica_1_1estados_1_1birthanddeath_1_1GameOver.html#a14173c013132ccc5cd3905b32576be1f',1,'Planet_Bound.logica.estados.birthanddeath.GameOver.novoJogo()'],['../classPlanet__Bound_1_1logica_1_1estados_1_1EstadoAdapter.html#a1dd7000a53f87c6599a01ba38d61084e',1,'Planet_Bound.logica.estados.EstadoAdapter.novoJogo()'],['../interfacePlanet__Bound_1_1logica_1_1estados_1_1IEstado.html#a0ca19eab26fdf19a980fcfb12e193a44',1,'Planet_Bound.logica.estados.IEstado.novoJogo()'],['../classPlanet__Bound_1_1logica_1_1Ship.html#a0506bbb4a8ec17a757839631cd4e264d',1,'Planet_Bound.logica.Ship.novoJogo()'],['../classPlanet__Bound_1_1logica_1_1ShipObservavel.html#a339f6845986450bcfeb24b99b3d15aa7',1,'Planet_Bound.logica.ShipObservavel.novoJogo()']]],
  ['novoplanet_587',['novoPlanet',['../group__secops.html#ga5f3a816ff4f3dd579159eeb94c24e025',1,'Planet_Bound::logica::dados::ship::ShipDados']]],
  ['novoship_588',['NovoShip',['../classPlanet__Bound_1_1logica_1_1estados_1_1birthanddeath_1_1NovoShip.html#a28bba8f52214b194e52c67ba8b7b0958',1,'Planet_Bound::logica::estados::birthanddeath::NovoShip']]]
];
