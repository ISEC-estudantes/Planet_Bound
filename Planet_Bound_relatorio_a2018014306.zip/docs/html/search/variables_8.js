var searchData=
[
  ['info_689',['Info',['../enumPlanet__Bound_1_1logica_1_1dados_1_1events_1_1EventType.html#a5bd147b9253db47b2d59d34174d8de39',1,'Planet_Bound::logica::dados::events::EventType']]],
  ['infoespaco_690',['infoEspaco',['../classPlanet__Bound_1_1ui_1_1gui_1_1info_1_1GRecursos.html#a269a3277fe05132f6b5e8e451bd2acda',1,'Planet_Bound::ui::gui::info::GRecursos']]],
  ['inicialspot_691',['InicialSpot',['../enumPlanet__Bound_1_1logica_1_1Ship_1_1ITerreno_1_1types.html#a43f7dbf505620fd0719f5a33b23c7d54',1,'Planet_Bound::logica::Ship::ITerreno::types']]]
];
