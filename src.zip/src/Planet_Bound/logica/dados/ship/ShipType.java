package Planet_Bound.logica.dados.ship;

import java.io.Serializable;

public enum ShipType  implements Serializable {
    military, mining, placeholder
}
