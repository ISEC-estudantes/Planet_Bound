package Planet_Bound.logica.dados.aux;

public enum Officer {
    Captain, Navigation, Landing, Shilds, Weapons, Cargo

}
